// For future interactivity
console.log("Portfolio loaded successfully!");
